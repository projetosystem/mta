addEventHandler('onClientResourceStart', resourceRoot, 
function() 
	txd = engineLoadTXD ( "105.txd" )
	engineImportTXD ( txd, 105 )
        
	dff = engineLoadDFF ( "105.dff", 105 )
        engineReplaceModel ( dff, 105 )
end 
)