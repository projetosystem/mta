txd = engineLoadTXD("59.txd")
engineImportTXD(txd, 59)
dff = engineLoadDFF("59.dff", 59)
engineReplaceModel(dff, 59)



