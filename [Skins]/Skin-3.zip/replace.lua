txd = engineLoadTXD("97.txd")
engineImportTXD(txd, 97)
dff = engineLoadDFF("97.dff",97)
engineReplaceModel(dff, 97)

-- generated with http://mta.dzek.metal.info/