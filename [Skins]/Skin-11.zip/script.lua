-- Generated using GM2MC ( GTA:SA Models To MTA:SA Converter ) by SoRa

addEventHandler('onClientResourceStart',resourceRoot,function () 
txd = engineLoadTXD( 'wmyst.txd' ) 
engineImportTXD( txd, 20 ) 
dff = engineLoadDFF('wmyst.dff', 20) 
engineReplaceModel( dff, 20 )
end)
