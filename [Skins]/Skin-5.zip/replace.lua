txd = engineLoadTXD("180.txd")
engineImportTXD(txd, 180)
dff = engineLoadDFF("180.dff",180)
engineReplaceModel(dff, 180)

-- generated with http://mta.dzek.metal.info/