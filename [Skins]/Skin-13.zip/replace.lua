txd = engineLoadTXD("data/28.txd")
engineImportTXD(txd, 28)
dff = engineLoadDFF("data/28.dff", 28)
engineReplaceModel(dff, 28)

-- generated with http://Mods-MTA.blogspot.com.br/