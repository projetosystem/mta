-- Generated using GM2MC ( GTA:SA Models To MTA:SA Converter ) by SoRa

addEventHandler('onClientResourceStart',resourceRoot,function () 
txd = engineLoadTXD( 'vmaff1.txd' ) 
engineImportTXD( txd, 107 ) 
dff = engineLoadDFF('vmaff1.dff', 107) 
engineReplaceModel( dff, 107 )
end)
