txd = engineLoadTXD("141.txd")
engineImportTXD(txd, 141)
dff = engineLoadDFF("141.dff", 141)
engineReplaceModel(dff, 141)

-- generated with http://mta.dzek.metal.info/