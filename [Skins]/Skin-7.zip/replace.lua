txd = engineLoadTXD("18.txd")
engineImportTXD(txd, 18)
dff = engineLoadDFF("18.dff", 18)
engineReplaceModel(dff, 18)



