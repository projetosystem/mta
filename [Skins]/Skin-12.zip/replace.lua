txd = engineLoadTXD("136.txd")
engineImportTXD(txd, 136)
dff = engineLoadDFF("136.dff", 136)
engineReplaceModel(dff, 136)

-- generated with http://mta.dzek.metal.info/