-- Generated using GM2MC ( GTA:SA Models To MTA:SA Converter ) by SoRa

addEventHandler('onClientResourceStart',resourceRoot,function () 
txd = engineLoadTXD( 'WalkMK.txd' ) 
engineImportTXD( txd, 48 ) 
dff = engineLoadDFF('WalkMK.dff', 48) 
engineReplaceModel( dff, 48 )
end)
