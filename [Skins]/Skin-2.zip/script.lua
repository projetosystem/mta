-- Generated using GM2MC ( GTA:SA Models To MTA:SA Converter ) by SoRa

addEventHandler('onClientResourceStart',resourceRoot,function () 
txd = engineLoadTXD( '14.txd' ) 
engineImportTXD( txd, 14 ) 
dff = engineLoadDFF('14.dff', 14) 
engineReplaceModel( dff, 14 )
end)
