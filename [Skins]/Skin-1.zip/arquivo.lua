function replaceModel() 
  txd = engineLoadTXD("228.txd", 228 )
  engineImportTXD(txd, 228)
  dff = engineLoadDFF("228.dff", 228 )
  engineReplaceModel(dff, 228)
end
addEventHandler ( "onClientResourceStart", getResourceRootElement(getThisResource()), replaceModel)