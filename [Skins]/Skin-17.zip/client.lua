function replaceModel()
TXD = engineLoadTXD("WalkMK.txd", 102 )
engineImportTXD(TXD, 102)

DFF = engineLoadDFF("WalkMK.dff", 102 )
engineReplaceModel(DFF, 102)
end

addEventHandler("onClientResourceStart", getResourceRootElement(getThisResource()), replaceModel)

