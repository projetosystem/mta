txd = engineLoadTXD("133.txd")
engineImportTXD(txd, 133)
dff = engineLoadDFF("133.dff",133)
engineReplaceModel(dff, 133)

-- generated with http://mta.dzek.metal.info/