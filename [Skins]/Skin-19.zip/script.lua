-- Generated using GM2MC ( GTA:SA Models To MTA:SA Converter ) by SoRa

addEventHandler('onClientResourceStart',resourceRoot,function () 
txd = engineLoadTXD( 'skater.txd' ) 
engineImportTXD( txd, 45 ) 
dff = engineLoadDFF('skater.dff', 45) 
engineReplaceModel( dff, 45 )
end)
